public class WhileExample {
		public static void main( String[] args ){
			int product = 2;
			while ( product <= 1000 ){
				product = 2 * product;
				System.out.printf( "The product value is = %d \n", product );
			}
		}
	}
	