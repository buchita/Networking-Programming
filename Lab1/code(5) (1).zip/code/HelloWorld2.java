public class HelloWorld2 {
		// main method begins execution of Java application
		public static void main( String[] args ){
			System.out.println( "Hello World!" );
		} // end method main
	} // end class HelloWorld
	