// Printing a line of text with multiple statements. 
public class HelloWorld3 {
// main method begins execution of Java application
     public static void main( String[] args ){

			System.out.print( " Hello World! Welcome to " );
			System.out.println( "Java Programming." );

		} // end method main
	} // end class HelloWorld3