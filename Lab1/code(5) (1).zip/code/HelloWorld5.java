// Displaying multiple lines with method System.out.printf.

public class HelloWorld5 {
 // main method begins execution of Java application
 
		public static void main( String[] args ){
			System.out.printf( "%s \n %d","HelloWorld",123 );
		} // end method main
	} // end class HelloWorld5