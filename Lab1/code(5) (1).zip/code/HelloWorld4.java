// Printing multiple lines of text with a single statement. 
public class HelloWorld4 {
// main method begins execution of Java application
	 public static void main( String[] args ){
			System.out.println( "HelloWorld!\n Welcome\n to\n Java Programming." );
		} // end method main
	} // end class HelloWorld4