public class Increment {
		public static void main( String[] args ) {
 
		 int c;
		 c = 5; // assign 5 to c
		 System.out.println( c ); // 5 prints 
		 System.out.println( c++ ); // 5 prints  
		 System.out.println( c ); // 6 prints 
		 System.out.println(); // skip a line

		 // demonstrate prefix increment operator
		 c = 5; // assign 5 to c
		 System.out.println( c ); // 5 prints 
		 System.out.println( ++c ); // 6  
		 System.out.println( c ); // 6 prints 
		} // end main
	} // end class Increment

